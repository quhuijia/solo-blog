title: Linux使用ssh远程连接
date: '2019-11-28 12:02:35'
updated: '2019-11-28 12:03:01'
tags: [linux, ssh]
permalink: /articles/2019/11/28/1574913755406.html
---
Linux远程连接指令:`ssh user@hostname`
本文已本地win10的Linux子系统连接腾讯云远程Ubuntu服务器为例。
输入指令`ssh ubuntu@111.231.xxx.xxx`
返回`Permission denied (publickey)`
因为我服务器开启了密钥方式链接，没有使用密钥肯定连不上。

#### 正确步骤：
1. `ssh-agent bash` 打开ssh-agent
2. `ssh-add 密钥文件`，添加密钥文件。添加成功会显示`Identity added:密钥文件名`。
3. `ssh ubuntu@111.231.xxx.xxx` 可以正常登录了。

#### 可能问题：
* `Permission denied (publickey)`
需要添加密钥，执行1、2步骤。
* `Could not open a connection to your authentication agent`
需要打开`ssh-agent`，执行步骤1即可。
*
 ```
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@ WARNING: UNPROTECTED PRIVATE KEY FILE! @
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
Permissions 0777 for ‘*’ are too open.
It is required that your private key files are NOT accessible by others.
This private key will be ignored.
Load key “*”: bad permissions
```
权限太高，降低权限`sudo chmod 600 密钥文件名`
* 每次退出shell再打开都要重现打开`ssh-agent`添加密钥。

