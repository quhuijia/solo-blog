title: signalR使用总结
date: '2019-11-18 13:16:20'
updated: '2019-11-26 14:58:48'
tags: [网络通信, c#, signalR]
permalink: /articles/2019/11/18/1574054180349.html
---
以前做服务端用过signalR，现在做winform客户端要连java服务端的Netty、websocket。经测试，signalRClient连接Netty服务端失败，客户端打算使用WebSocket编程连接java服务端。重新复习signalR，然后使用c#中ClientWebSocket连接signalR，来为下一步连接java服务端做准备。
### SignalR服务端
 详见微软官方文档，简略说明。
选择“Web 应用程序”以创建使用 Razor Pages 的项目
  Startup.cs文件中添加 
```  
public void ConfigureServices(IServiceCollection services)   
 {   
     services.AddSignalR();   
 }   
 app.UseEndpoints(endpoints =>   
 {   
     endpoints.MapHub<ChatHub>("/chatHub"); |   
 });  
```

  新建ChatHub.cs文件 
  ```  
public class ChatHub:Hub |   
 {   
     public async Task SendMessage(string userId,string message) |   
     {   
         await Groups.AddToGroupAsync(Context.ConnectionId,userId); |   
         await Clients.Groups(userId).SendAsync("ReceiveMessage", userId, message); |   
         //await Clients.Caller.SendAsync("ReceiveMessage", userId, message); |   
         //await Clients.All.SendAsync("ReceiveMessage", userId, message); |   
     }   
 }  
```
 
### 客户端使用SignalRClient
 使用signalRClient 
 详见微软官方文档，简略说明。 
引入`Microsoft.AspNetCore.SignalR.Client`
建立连接：
```
 //建立连接
 HubConnection connection; 
    connection = new HubConnectionBuilder()    
    .WithUrl("https://localhost:44350/ChatHub") 
    .Build(); 
//注册客户端处理事件
 connection.On<string,string>("ReceiveMessage", (user,message) =>    
  { 
      Console.WriteLine($"{user}:{message}"); 
  });

 //发送消息 
await connection.SendAsync("SendMessage12", user,message);         
```

### 客户端使用websocket编程
```
string BaseUrl = "wss://localhost:44350/chatHub"; 
ClientWebSocket client = new ClientWebSocket(); 
await client.ConnectAsync(new Uri(BaseUrl), CancellationToken.None);     //建立连接
await client.SendAsync(new ArraySegment<byte>(AddSeparator(Encoding.UTF8.GetBytes(@"{""protocol"":""json"", ""version"":1}"))) 
, WebSocketMessageType.Binary, true, CancellationToken.None);    //定义传输方式，建立连接后第一次通信时发送：

 //按照signalR的数据格式来组成要传输的数据
 var sendJson = $@"{{ 
  ""arguments"": [""{sendData1}"", ""{sendData2}""], 
  ""invocationId"": ""1"", 
  ""streamIds"": [], 
  ""target"": ""{SendMessage}"", 
  ""type"": 1 
  }}";          
  var bytes = Encoding.UTF8.GetBytes(sendJson); 

//发送数据
await client.SendAsync(new ArraySegment<byte>(AddSeparator(bytes)), WebSocketMessageType.Binary, true, CancellationToken.None);    

var buffer = new ArraySegment<byte>(new byte[1024]); 
await client.ReceiveAsync(buffer, CancellationToken.None);    //接受数据

//发送数据添加分隔符，接受数据删除分隔符 
  private static byte[] AddSeparator(byte[] data) 
  { 
      List<byte> t = new List<byte>(data) { 0x1e };//0x1e record separator 
      return t.ToArray(); 
  } 
  private static byte[] RemoveSeparator(byte[] data) 
  { 
      List<byte> t = new List<byte>(data); 
      t.Remove(0x1e); 
      return t.ToArray(); 
  } 
```
