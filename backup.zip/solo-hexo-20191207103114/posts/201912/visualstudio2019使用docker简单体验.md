title: visual studio2019 使用docker简单体验
date: '2019-12-03 16:21:13'
updated: '2019-12-03 16:21:13'
tags: [docker]
permalink: /articles/2019/12/03/1575361273269.html
---
新建一个项目，启用docker。

![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/userdocker.png)

编译失败，报错：

```
错误	CTC1001	未启用卷共享。在 Docker Desktop 的设置屏幕上，单击“共享驱动器”，选择包含项目文件的驱动器。	

```
根据提示在设置中勾选项目所在磁盘：
![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/shareddrives.png
)

提交时要输入密码。

编译生成成功，会自动生成了相应的image。
WSL的bash中使用`docker image ls`找到生成的image。
发现容器中程序默认使用的是80端口，映射到本机5000端口，`docker run -p 5000:80 [imageId]`
用浏览器访问`localhost:5000`
![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/dockertest.png
)

