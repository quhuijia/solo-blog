title: c#的TCP通信
date: '2019-11-25 18:34:20'
updated: '2019-11-26 14:58:02'
tags: [网络通信, c#, TCP]
permalink: /articles/2019/11/25/1574678060292.html
---
## 客户端
`TcpClient`类提供了网络连接、发送和接收流数据的简单方法。  
可以通过两种方式连接到TCP服务器。  
* 可以通过无参构造函数创建实例，然后调用`Connect`方法连接  
```  
TcpClient tcpClient = new TcpClient ();   
IPAddress ipAddress = Dns.GetHostEntry ("www.xxx.com").AddressList[0];  
 tcpClient.Connect (ipAddress, 11003);  
```  
* 通过服务器地址和端口号创建实例，构造函数将自动连接  
```  
TcpClient client = new TcpClient(server, port);  
```  
`TcpClient`创建完成后调用`GetStream()`方法获取`NetworkStream`，用`Write()`和`Read()`方法发送和接受数据。  
 备注  
  
**注意：**   
* 关闭`TcpClient`后，`NetworkStream`不会自动释放。  
* `Read()`和`Write()`方法会一直阻塞，知道满足执行条件后执行。  
* `Read()`方法最好用`try...catch`捕捉异常。无论是在客户端还是服务端正常退出都很容易导致`Read()`方法触发异常：`一个封锁操作被对 WSACancelBlockingCall 的调用中断。`

测试代码：
```
using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MyTCPClinet
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ClientRun!");
            int portNum = 5001;
            string hostName = "192.168.0.166";
            TcpClient tcpClient = new TcpClient(hostName, portNum);
            NetworkStream networkStream = tcpClient.GetStream();
          
            //创建新线程接收控制台输入，然后发送数据给TCP服务端
            Task.Run(() =>
            {
                while (true)
                {
                    var sendData = Console.ReadLine();
                    if (sendData == "exit") //控制台输入exit关闭连接
                    {
                        networkStream.Close();
                        tcpClient.Close();
                        break;
                    }
                    var byteSend = Encoding.UTF8.GetBytes(sendData);
                    networkStream.Write(byteSend, 0, byteSend.Length);

                }

            });

            int i = 0;
            byte[] byteData = new byte[1024];

            //创建新线程接受数据
            Task.Run(() =>
            {
               
                while ( true)
                {
                    try
                    {
                        if ((i = networkStream.Read(byteData, 0, byteData.Length)) != 0)
                        {

                            var receiveString = Encoding.UTF8.GetString(byteData,0,i);
                            Console.WriteLine($"服务端返回：{receiveString}");
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                        break;
                    }
                }
            });

            while (true)//阻止main方法退出
            { }
            //Console.WriteLine("Client退出！");
        }
    }
}
```
## 服务端
`TcpListener` 类提监听和接受传入连接请求， `Start()`方法开始侦听传入连接请求。 它将排队传入的连接，直到调用`Stop()`方法或它已排队已达到`MaxConnections`为止。 
### 同步方式
使用` AcceptSocket`或 `AcceptTcpClient`从传入连接请求队列处理连接， 这两种方法将会阻塞，即**每次只能加载处理一个客户端连接**，直到这个连接断开才会处理队列里的下一个连接。

**注意：**   
* 同步方式每次只能处理一个客户端连接。  
* `Read()`方法最好用`try...catch`捕捉异常。客户端异常退出很容易导致`Read()`方法触发异常：`Unable to read data from the transport connection: 远程主机强迫关闭了一个现有的连接。`

测试代码：

```
using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TCPServer
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("serverRun!");
            int portNum = 5001;
            TcpListener tcpListener = new TcpListener(portNum);
            tcpListener.Start();
            while (true)
            {
                TcpClient client = tcpListener.AcceptTcpClient();
                //Console.WriteLine(client.Client.LocalEndPoint);
                //Console.WriteLine(client.Client.RemoteEndPoint);
                NetworkStream networkStream = client.GetStream();

                int i = 0;
                byte[] receiveData = new byte[1024];
                try
                {
                    while ((i = networkStream.Read(receiveData, 0, receiveData.Length)) != 0)
                    {
                        var receiveString = Encoding.UTF8.GetString(receiveData, 0, i);
                        Console.WriteLine($"收到请求：{receiveString}");
                        var sendString = $"服务端返回：{receiveString}";
                        networkStream.Write(Encoding.UTF8.GetBytes(sendString));
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.GetType().Name);
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
```

### 异步方式
**异步方式可以连接多个客户端**。使用`BeginAcceptTcpClient()`开始异步操作以接受传入的连接尝试，他需要传入一个一个`AsyncCallback()`委托。在委托中通过调用`EndAcceptTcpClient()`方法获取`TcpClient`



**注意：**   
* 异步`BeginAcceptTcpClient()`操作必须通过调用`EndAcceptTcpClient()`方法来完成TcpClient实例的创建。`EndAcceptTcpClient()`方法方法在`callback`委托中调用。
* `BeginAcceptTcpClient()`方法不会阻塞。`EndAcceptTcpClient()`方法会阻塞。
* 因为`BeginAcceptTcpClient()`方法不会阻塞，使用时往往需要ManualResetEvent来进行控制，否则会不断创建，直到服务器资源耗尽。

测试代码：
```
using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TCPServer
{
    class Program
    {
        public static ManualResetEvent tcpClientConnected = new ManualResetEvent(false);
        static async Task Main(string[] args)
        {
            Console.WriteLine("serverRun!");
            int portNum = 5001;
            TcpListener tcpListener = new TcpListener(portNum);
            tcpListener.Start();
          
            while (true)
            {
                tcpClientConnected.Reset();
                tcpListener.BeginAcceptTcpClient(
                new AsyncCallback(ServerHandle),
                tcpListener);
               tcpClientConnected.WaitOne();
            }
        }

        static void ServerHandle(IAsyncResult ar)
        {
            TcpListener tcpListener = (TcpListener)ar.AsyncState;
            TcpClient client = tcpListener.EndAcceptTcpClient(ar);
            tcpClientConnected.Set();
            NetworkStream networkStream = client.GetStream();

            int i = 0;
            byte[] receiveData = new byte[1024];
            try
            {
                while ((i = networkStream.Read(receiveData, 0, receiveData.Length)) != 0)
                {
                    var receiveString = Encoding.UTF8.GetString(receiveData, 0, i);
                    Console.WriteLine($"收到来自{client.Client.RemoteEndPoint}的请求：{receiveString}");
                    var sendString = $"服务端返回：{receiveString}";
                    networkStream.Write(Encoding.UTF8.GetBytes(sendString));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.GetType().Name);
                Console.WriteLine(e.Message);
            }
        }
    }
}
```
