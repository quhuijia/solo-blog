title: Android上使用Ubuntu运行.netcore
date: '2019-11-27 17:14:21'
updated: '2019-11-27 17:21:01'
tags: [linux, Ubuntu, .netcore, Termux]
permalink: /articles/2019/11/27/1574846061212.html
---
因为.netcore跨平台、支持Linux，原本想Android是基于Linux开发的，还以为会很简单就可以运行.netcore，研究了一下，并不方便。
我现在思路是：在Android上运行一个Linux环境，再在其中运行.netcore。
Android上运行Linux方法可能有很多。这里使用Termux中安装Ubuntu发行版。
### 1. 安装Ubuntu
`mkdir ~/ubuntu -p`
`cd ~/ubuntu`
`wget https://raw.githubusercontent.com/Neo-Oli/termux-ubuntu/master/ubuntu.sh`
`chmod +x ubuntu.sh`
`bash ubuntu.sh`

### 2. 运行Ubuntu
`chmod +x start-ubuntu.sh  `
`bash start-ubuntu.sh`

如果成功了应该会显示：  
`root@localhost:~#`
### 3. 更改DNS
(网上资料里这样做，我直接照做了，不知道是否是必须)

返回Termux并修改 `resolv.conf`
`exit`
`vim ~/ubuntu/ubuntu-fs/etc/resolv.conf`

按下例修改DNS并保存退出
```
nameserver 8.8.8.8
nameserver 8.8.4.4
```
### 4. 安装所需软件  
`apt-get update`  
`apt-get install vim wget apt-transport-https -y`

### 5. 安装.netcore
```
apt-get install curl libunwind8 gettext wget unzip -y
wget https://dotnetcli.blob.core.windows.net/dotnet/Runtime/release/3.0/dotnet-runtime-latest-linux-arm64.tar.gz
mkdir -p /opt/dotnet && sudo tar zxf dotnet-runtime-latest-linux-arm64.tar.gz -C /opt/dotnet
```
`ln -s /opt/dotnet/dotnet /usr/local/bin`
输入命令 `dotnet --info` 可判断是否安装成功。
