title: docker简介及简单操作
date: '2019-11-28 16:53:09'
updated: '2019-11-28 17:26:36'
tags: [docker]
permalink: /articles/2019/11/28/1574931189209.html
---
docker是一种容器技术，docker容器包含软件运行的所有依赖，为软件提供独立、隔离的运行环境。
### docker优点和作用
* 解决开发和线上环境之间的差异，方便部署
* 可以在一台服务器部署运行多个异构软件，软件之间彼此隔离互不干扰。
* 相较于以前的虚拟机技术，docker占用资源更少，启动快速。
* 结合k8之类容器管理工具，可以方便的对容器管理，实现服务的扩容、缩容。

### docker使用
* 安装docker
参看[官方文档](https://docs.docker.com/install/linux/docker-ce/ubuntu/)
* docker需要root用户权限，可以指令前加`sudo`，也可以可以把用户加入 Docker 用户组参看[官方文档](https://docs.docker.com/install/linux/linux-postinstall/#manage-docker-as-a-non-root-user)
* image镜像基本操作
image翻译成镜像有点不好理解。image包含了应用程序及其依赖，通过image生成container来运行应用程序。多个container可以共享一个image。
```
//拉取image
docker pull [imageName]
//查看本机所有image
docker image ls
//删除image
docker image rm [imageName]
```
* 容器基本操作
```
//运行容器
docker run --name [containerName] --rm -p 1001:1002  [imageName] 
//查看运行中的容器
docker ps
//查看本机所有容器
docker ps -a
//停止容器
docker stop [containerName|containerId]
//强制停止容器
docker kill [containerName|containerId]
//开始容器
docker start [containerName|containerId]
//重新运行
docker restart [containerName|containerId]
//删除容器
docker rm [containerName|containerId]
//查看容器内shell输出
docker logs [containerName|containerId]
//进入容器使用shell
docker exec -it [containerName|containerId] bash
```
参数说明：
`--rm` 容器停止时删除
`--name`为容器起名，之后可以通过容器名操作容器
`-p` 端口映射，此例1001外部访问容器端口，1002内部程序端口
`[-v|--volume] [localPath]:[dockerPath]`将本机目录和容器目录建
立映射，修改本机目录下文件就相当于修改容器目录下文件
`[-d|--detach]`后台运行容器
`[-e|--env] [argument]=value`向容器进程传入一个环境变量`argument`值为value
其他参数：
```
以后补充
```
* 制作自己的image
 在项目的根目录下，`.dockerignore`和`Dockerfile`文件。
`.dockerignore`文件写入不需要打包进image的文件。
`Dockerfile`编写打包指令如下：
```
FROM [imageName]
COPY .  /app
WORKDIR /app
RUN 
CMD
```
```
FROM [sourceImageName]：依赖的基础image包。
COPY . /app：将当前目录下的所有文件（除了.dockerignore排除的路径），都拷贝进入 image 文件的/app目录。
WORKDIR /app：指定工作路径为/app。
RUN xxx：在/app目录下，运行xxx命令，一般用来安装依赖。安装后所有的依赖，都将打包进入 image 文件，可以有多个RUN命令。
CMD xxx：容器启动后执行命令，只能有一个CMD命令
```
  有了 Dockerfile 文件以后，就可以使用`docker image build`命令创建 image 文件了。
```
$ docker image build -t [imageName] .
# 或者
$ docker image build -t [imageName]:0.0.1 .
```

`-t`参数用来指定 image 文件的名字，后面还可以用冒号指定标签。如果不指定，默认的标签就是`latest`。最后的那个点表示 Dockerfile 文件所在的路径，上例是当前路径，所以是一个点。
