title: win10子系统WSL安装docker
date: '2019-12-03 15:46:08'
updated: '2019-12-03 15:46:08'
tags: [docker]
permalink: /articles/2019/12/03/1575359168587.html
---
服务里打开子系统，应用商店下载ubuntu。
之前有ubuntu服务器装过docker，一路按照官方文档安装，都很顺利，没有报错。装完运行`docker ps`，提示
`Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?`
网上有许多正确解答。看了几篇，大概了解原因。感觉[这篇文章](https://www.cnblogs.com/xiaoliangge/p/9134585.html)讲的比较清楚。
#### 原因：
docker的架构设计分为三个组件：一个客户端，一个REST API和一个服务器（守护进程）：

* Client ：与REST API交互。主要目的是允许用户连接守护进程。
* REST API：充当客户端和服务器之间的接口，实现通信。
* 守护进程：负责实际管理容器 - 启动，停止等。守护进程监听来自docker客户端的API请求。

守护进程与内核关系非常密切。今天在Windows中，当您运行Windows Server容器时，守护进程在Windows中运行。当您切换到Linux容器模式时，守护程序实际上在名为Moby Linux VM的虚拟机内运行。随着Docker [即将发布](https://blog.docker.com/2017/11/docker-for-windows-17-11/)，您将能够并行运行Windows Server容器和Linux容器，守护进程将始终作为Windows进程运行。

然而，客户端不必与守护进程安装在同一个地方。例如，您可以在开发计算机上使用本地Docker客户端与Azure中的Docker进行通信。这使我们可以让WSL中的客户端与主机上运行的守护进程通信。

简而言之，目前WSL是不支持Docker的守护进程，我们可以在WSL安装docker客户端，与其他主机上的docker守护进程通信，比如windows上的docker守护进程。

安装windows版本的docker，在Docker Desktop的Setting中勾选最后一项。
![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/dockerdesk.png)

在WSL中指定要连接的守护进程：
`echo "export DOCKER_HOST=tcp://localhost:2375" >> ~/.bashrc && source ~/.bashrc`
然后就可以在WSL中使用docker了
