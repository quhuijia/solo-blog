title: 使用xshell终端连接腾讯云
date: '2019-11-20 14:34:25'
updated: '2019-11-20 15:53:33'
tags: [linux]
permalink: /articles/2019/11/20/1574231665415.html
---
网页终端简单方便但是功能不多，没法上传文件。以前主要window编程，对Linux终端工具接触不多。试了下winscp，winscp功能单一，不能运行指令，并不方便；xshell界面美观，功能丰富，满足我的全部需求，决定使用xshell。

本文使用密钥方式连接服务器。
### 1. 腾讯云添加ssh密钥
在腾讯云密钥[ssh密钥控制台](https://console.cloud.tencent.com/cvm/sshkey)创建密钥。

创建完成后，下载私钥。在控制台选中密钥，点击绑定/解绑实例，完成绑定。
需要关闭服务器。
[ssl密钥管理腾讯云官方文档](https://cloud.tencent.com/document/product/213/16691)

### 2. xshell密钥方式连接服务器
xshell新建会话，输入服务器地址。点击“用户身份验证”，输入用户名，用户密钥选择上一步下载的证书，点击确认新建会话。然后选择会话进行连接。

![image36516202.png](https://img.hacpai.com/file/2019/11/image36516202-9df2fde7.png)

### 3. xshell上传文件
上传文件如果不是root用户往往权限不够，需要以下步骤：
* `sudo passwd root `指令创建root账户密码，确认密码。
* `su root` 切换到root账户。
* `apt-get install lrzsz` 安装 lrzsz。
* `cd`进上传目标目录，输入`rz`指令，弹出文件选择框，选择想上传的文件，开始上传。
