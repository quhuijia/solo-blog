title: C#的UDP通信
date: '2019-11-26 14:56:55'
updated: '2019-11-26 14:56:55'
tags: [网络通信, c#, udp]
permalink: /articles/2019/11/26/1574751415292.html
---
**UDP特点：**
* UDP是无连接的，没有客户端和服务端的差别，一个UDP客户机可以向多个UDP客户机发送数据，也可以从多个UDP客户机接收数据。
* UDP不需要建立连接，包头小，面向报文，无阻塞控制，所以UDP比TCP效率更高，但不可靠。
* UDP和TCP都是双工通信。


c#使用`UdpClient `可以方便的实现udp通信。

**注意：**
* UDP是无连接的，不需要调用`Connect()`方法就可以收发信息。调用`Connect()`方法后只能接收来自该方法指定的服务器的信息。

测试代码：
```
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace UDPClient3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("13000 ClinetStart!");
            UdpClient udpClient = new UdpClient(13000);
            //udpClient.Connect("192.168.0.166", 12000);
            Task.Run(() =>
            {
                while (true)
                {
                    var sendData = Console.ReadLine();
                    Byte[] sendBytes = Encoding.UTF8.GetBytes(sendData);
                    udpClient.Send(sendBytes, sendBytes.Length, "192.168.0.166",11000);
                    udpClient.Send(sendBytes, sendBytes.Length, "192.168.0.166", 12000);
                }
            });

            IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);
            Task.Run(() =>
            {
                while (true)
                {
                    byte[] receiveBytes = udpClient.Receive(ref RemoteIpEndPoint);
                    string returnData = Encoding.UTF8.GetString(receiveBytes);
                    Console.WriteLine($"{returnData}信息来自{RemoteIpEndPoint.Address.ToString()},{RemoteIpEndPoint.Port.ToString()}");
                }
            });

            while (true)
            {
            }
        }
    }
}
```
