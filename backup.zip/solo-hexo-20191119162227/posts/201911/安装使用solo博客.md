title: 安装使用solo博客
date: '2019-11-18 10:22:28'
updated: '2019-11-18 13:49:47'
tags: [Solo]
permalink: /articles/2019/11/18/1574043748049.html
---
CDNS 广告太多，博客园界面太老旧，看着都没有欲望。本来想自己做。但工程量也不小，而且网上有不少开源框架，没必要在重复劳动了。网上搜了搜开源博客框架，相对来说，比较看重页面效果、美观度。最后选了 Solo 博客。

## 安装solo步骤：
服务系统ubuntu 18，使用docker方式安装，参考了[从零开始安装solo教程](https://hacpai.com/article/1565021959471)。
### 1. 安装docker
参考官方文档：https://docs.docker.com/install/linux/docker-ce/ubuntu/

### 2. 安装mysql
```
//MYSQL_ROOT_PASSWORD=你的数据库密码 ，docker安装的mysql默认允许远程连接
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=XXXXX -d mysq

//进入容器
docker exec -it mysql bash 

//进入数据库 p后面跟你的密码 
mysql -uroot -pXXXXX

//创建数据库(数据库名:solo;字符集utf8mb4;排序规则utf8mb4_general_ci) 
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci; 
//出现Query OK, 1 row affected (0.00 sec)表示成功 

//退出数据库 
exit 

//退出容器 
exit
```

### 3. 安装solo
```
sudo docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="xxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" \
    b3log/solo --listen_port=8001 --server_scheme=http --server_host=xxx.xxx.xxx --server_port=8001
```

上面的命令建议手敲，免得出错，参数说明

* `--env JDBC_PASSWORD="xxxxx"` 将 xxxxx 换成你的密码
* `--listen_port=8001` 监听的端口
* `--server_scheme=http` 请求方式，暂时使用 http，后面我们会换成 https
* `--server_host=xxx.xxx.xxx` 你的域名，如果你没有域名可以写 ip 地址
* `--rm`因为这个容器后面要删掉，带上 rm 会省很多事。

如果你不想使用 nginx 也不想升级 https，那么你可以先执行`docker stop solo`，然后将上面`--listen_port=8080`的`8080`换成`80`，然后去掉`--rm`，再执行一次就 ok。
命令成功执行没有报错的话，通过`docker ps`查看执行的容器列表中是否存在 solo，存在这表示启动成功，直接访问你的域名加:8080 即可访问你的博客。

## 总结安装中遇到的问题
* 使用了最新mysql（习惯了用新不用旧）导致solo启动失败。使用docker logs solo查看错误发现错误信息：`java.sql.SQLNonTransientConnectionException: Public Key Retrieval is not allowed`搜索查得mysql 8.0版本以上需要添加参数`allowPublicKeyRetrieval=true`。
* 我使用8001端口，打开页面提示配置错误，添加 `--server_port=8001`
