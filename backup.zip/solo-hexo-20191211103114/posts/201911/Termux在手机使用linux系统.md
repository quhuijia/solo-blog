title: Termux，在手机使用linux系统
date: '2019-11-27 16:40:12'
updated: '2019-11-27 16:40:12'
tags: [linux, Termux, android]
permalink: /articles/2019/11/27/1574844012283.html
---
[Termux](https://termux.com/) 是一个安卓手机的 Linux 模拟器，可以在手机上模拟 Linux 环境。它提供一个命令行界面，让用户与系统互动。

它就是一个普通的手机 App，可以从应用商店下载安装。不需要 root 权限，也不需要设置，打开就能使用。

### 1. 安装Termux
* 这里使用`酷安`安装。下载酷安app，搜索`Termux`安装。
### 2. 更换清华源镜像
```
export EDITOR=vi
apt edit-sources
```
把第二行替换成以下内容
	`
    deb [arch=all,aarch64]    https://mirrors.tuna.tsinghua.edu.cn/termux stable main
	`
### 3.  安装软件
例如安装`wget`、`vim`、`unzip`、`proot`
```
apt update
apt upgrade
apt install wget unzip proot vim -y
```
### 4. 其他指令
* `termux-setup-storage` //访问手机文件存储
这会在当前目录下生成一个`storage`子目录，它是手机存储的符号链接，后文下载文件就是到这个目录去下载。
* `pkg list-all` //列出所有软件



