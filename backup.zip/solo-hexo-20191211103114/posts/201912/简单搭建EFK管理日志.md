title: 简单搭建EFK管理日志
date: '2019-12-09 11:21:00'
updated: '2019-12-09 11:32:43'
tags: [EFK, elasticsearch]
permalink: /articles/2019/12/09/1575861660671.html
---
## 认识EFK

EFK不是一个软件，而是一套解决方案，并且都是开源软件，之间互相配合使用，完美衔接，高效的满足了很多场合的应用，是目前主流的一种日志系统。EFK是三个开源软件的缩写，分别表示：Elasticsearch , FileBeat, Kibana , 其中ELasticsearch负责日志保存和搜索，FileBeat负责收集日志，Kibana 负责界面,当然EFK和大名鼎鼎的ELK只有一个区别，那就是EFK把ELK的Logstash替换成了FileBeat，因为Filebeat相对于Logstash来说有2个好处：  
1、侵入低，无需修改程序目前任何代码和配置  
2、相对于Logstash来说性能高，Logstash对于IO占用很大

当然FileBeat也并不是完全好过Logstash，毕竟Logstash对于日志的格式化这些相对FileBeat好很多，FileBeat只是将日志从日志文件中读取出来，当然如果你日志本身是有一定格式的，FileBeat也可以格式化，但是相对于Logstash来说，还是差一点

**Elasticsearch**

Elasticsearch是个开源分布式搜索引擎，提供搜集、分析、存储数据三大功能。它的特点有：分布式，零配置，自动发现，索引自动分片，索引副本机制，restful风格接口，多数据源，自动搜索负载等。

**FileBeat**

Filebeat隶属于Beats。目前Beats包含六种工具：  
Packetbeat（搜集网络流量数据）  
Metricbeat（搜集系统、进程和文件系统级别的 CPU 和内存使用情况等数据）  
Filebeat（搜集文件数据）  
Winlogbeat（搜集 Windows 事件日志数据）  
Auditbeat（ 轻量型审计日志采集器）  
Heartbeat（轻量级服务器健康采集器）

**Kibana**

Kibana可以为 Logstash 、Beats和 ElasticSearch 提供的日志分析友好的 Web 界面，可以帮助汇总、分析和搜索重要数据日志。

**EFK架构图**
![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/efk.webp)

## 简易安装
#### 安装elasticsearch
1. 拉取 elasticsearch镜像
* `docker pull docker.elastic.co/elasticsearch/elasticsearch:7.5.0`  
* elasticsearch需要至少262144的虚拟内存数量。如果不够执行`sysctl -w vm.max_map_count=262144`
2. 拷贝elasticsearch配置文件
* `docker run --name elasticsearch -d -p 9200:9200  docker.elastic.co/elasticsearch/elasticsearch:7.5.0`启动容器，运行失败也没关系，只是拷贝出里面的配置文件。
* `docker cp elasticsearch:/usr/share/elasticsearch/config/elasticsearch.yml /data/dockerData/elasticsearch/config/kibana.yml`
3. 运行
```
docker run --name elasticsearch -d -p 9200:9200 -p 9300:9300 -e "discovery.type=single-node" \
-v /data/dockerData/elasticsearch/config/kibana.yml:/usr/share/elasticsearch/config/elasticsearch.yml  \
docker.elastic.co/elasticsearch/elasticsearch:7.5.0
```
#### 安装 kibana
1. 拉取镜像
`docker pull docker.elastic.co/kibana/kibana:7.5.0`
2. 拷贝出配置文件
`docker run    --user=root -d --name kibana docker.elastic.co/kibana/kibana:7.5.0 `
`docker cp kibana:/usr/share/kibana/config/kibana.yml /data/dockerData/kibana/config/kibana.yml`
3. 修改配置文件`/data/dockerData/kibana/config/kibana.yml`
`elasticsearch.hosts: [ "http://172.17.0.10:9200" ]`
4. 运行
```
docker run -d --name kibana  -p 5601:5601  \
-v /data/dockerData/kibana/config/kibana.yml:/usr/share/kibana/config/kibana.yml \
docker.elastic.co/kibana/kibana:7.5.0
```

#### 安装 filebeat
1. 拉取镜像
`docker pull docker.elastic.co/beats/filebeat:7.5.0`
2. 拷贝出相关配置文件
`docker cp filebeat:/usr/share/filebeat/filebeat.yml /data/dockerData/filebeat/filebeat.yml`
`docker cp  filebeat:/usr/share/filebeat/modules.d  /data/dockerData/filebeat/modules.d`
3. 修改配置文件`/data/dockerData/filebeat/filebeat.yml`
```
filebeat.inputs:
- type: log
  enabled: true
  paths:
    - /usr/share/filebeat/logs/nginx/*.log

output.elasticsearch:
  hosts: ["172.17.0.10:9200"]

setup.kibana:
  host: "172.17.0.10:5601"
```
4. 运行
```
docker run -d \
  --name=filebeat \
  --user=root \
  --volume="/data/dockerData/filebeat/filebeat.yml:/usr/share/filebeat/filebeat.yml"  \
  --volume="/data/dockerData/nginx/logs:/usr/share/filebeat/logs/nginx"   docker.elastic.co/beats/filebeat:7.5.0 
```
#### 安装结束
## 使用kibana查看日志
打开`yourIP:5601`查看，可以选择filter过滤，如图：
![notifyico.ico.png](https://orzwizard.vip/resource/image/blog/kibana.png)

#### 参考
[centos7搭建EFK日志分析系统](https://www.jianshu.com/p/4bf5a8b743d2)
[Install Elasticsearch with Docker](https://www.elastic.co/guide/en/elasticsearch/reference/current/docker.html)
[Running Kibana on Docker](https://www.elastic.co/guide/en/kibana/current/docker.html)
[Running Filebeat on Docker](https://www.elastic.co/guide/en/beats/filebeat/current/running-on-docker.html)

